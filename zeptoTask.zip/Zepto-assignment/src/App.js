import logo from './logo.svg';
import './App.css';

import AutoCompleteChips from './task.tsx';

function App() {
  return (
    <div className="App">
      <AutoCompleteChips/>
    </div>
  );
}

export default App;

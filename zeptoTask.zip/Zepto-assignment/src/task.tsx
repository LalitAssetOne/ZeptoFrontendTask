// AutoCompleteChips.tsx

import React, { useState, useRef, useEffect, KeyboardEvent } from 'react';
import icon1 from "./icons/profile1.jpg"
import icon2 from "./icons/profile2.jpg"
import icon3 from "./icons/profile3.jpg"
import icon4 from "./icons/profile4.jpg"
import icon5 from "./icons/profile5.jpg"
import icon6 from "./icons/profile6.jpg"
import icon7 from "./icons/profile7.jpg"


const AutoCompleteChips: React.FC = () => {
  const [inputValue, setInputValue] = useState<string>('');
  const [items, setItems] = useState<{ name: string; image: string; email: string }[]>([
    { name: 'Marina Augustine ', image: icon1, email: 'marina@gmail.com' },
    { name: 'Nick Giannopoulos', image: icon2, email: 'nick@gmail.com' },
    { name: 'Narayna Garner', image: icon3, email: 'Narayna@gmail.com' },
    { name: 'Anita Gros', image: icon4, email: 'Anita@gmail.com' },
    { name: 'Charlie Brown', image: icon5, email: 'Charlie@gmail.com' },
    { name: 'Megan Smith', image: icon6, email: 'marina@gmail.com'},
    { name: 'Charlie Brown', image: icon7, email: 'Charlie@gmail.com' },
  ]);
  const [selectedChips, setSelectedChips] = useState<{ name: string; image: string; email: string }[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(event.target.value);
  };

  const handleItemClick = (item: string) => {
    const selectedItem = items.find((i) => i.name === item);
    if (selectedItem) {
      setSelectedChips([...selectedChips, selectedItem]);
      setItems(items.filter((i) => i.name !== item));
      setInputValue('');
    }
  };

  const handleChipRemove = (chipName: string) => {
    const removedChip = selectedChips.find((chip) => chip.name === chipName);
    if (removedChip) {
      setSelectedChips(selectedChips.filter((chip) => chip.name !== chipName));
      setItems([...items, removedChip]);
    }
  };

  const handleBackspace = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Backspace' && inputValue === '' && selectedChips.length > 0) {
      const lastChip = selectedChips[selectedChips.length - 1];
      handleChipRemove(lastChip.name);
    }
  };

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  return (
    <div className="autocomplete-container">
      <div className="input-container">
        <label >Name </label>
        <input
          type="text"
          value={inputValue}
          onChange={handleInputChange}
          onKeyDown={handleBackspace}
          ref={inputRef}
          className="input"
        />
        {inputValue !== '' && (
          <ul className="autocomplete-list">
            {items
              .filter((item) => item.name.toLowerCase().includes(inputValue.toLowerCase()))
              .map((item) => (
                <li key={item.name} onClick={() => handleItemClick(item.name)} className="list-item">
                  <img src={item.image} alt={item.name} className="profile-image" />
                  <span>{item.name}</span>
                  <span style={{color:"grey",marginLeft:"10px"}}>{item.email}</span>

                </li>
              ))}
          </ul>
        )}
      </div>
      <div className="selected-chips">
        {selectedChips.map((chip) => (
          <div key={chip.name} className="chip">
            <img src={chip.image} alt={chip.name} className="chip-image" />
            {chip.name}
            <span className="remove-icon" onClick={() => handleChipRemove(chip.name)}>
              X
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AutoCompleteChips;
